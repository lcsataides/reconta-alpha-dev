<?php

# Modelo de estrutura pra Newsletter

?>

<h4>Acompanhe o Reconta Aí também por e-mail</h4>
<div class="footer-newsletter">
  <div class="field has-addons">
    <div class="control">
      <input class="input" type="text" placeholder="Insira seu e-mail@provedor.com.br">
    </div>
    <div class="control">
      <input class="button is-secondary" type="submit" value="Enviar">
    </div>
  </div>
</div>