<div class="column is-centered">
  <h4 class="has-text-centered">Sinto muito, não encontramos nenhum post.</h4>
</div>