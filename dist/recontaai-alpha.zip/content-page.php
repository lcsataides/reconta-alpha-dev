<section class="section-ultimas">
  <?php get_template_part('templates/ultimas-noticias') ?>
</section>
<section class="section-atualiza-ai">
  <?php get_template_part('templates/atualiza-ai') ?>
</section>
<section class="section-explica-ai">
  <?php get_template_part('templates/explica-ai') ?>
</section>
<section class="section-se-liga-ai">
  <?php get_template_part('templates/se-liga-ai') ?>
</section>
<section class="section-ouca-ai">
  <?php get_template_part('templates/ouca-ai') ?>
</section>
<section class="section-reconta-tv">
  <?php get_template_part('templates/reconta-tv') ?>
</section>
