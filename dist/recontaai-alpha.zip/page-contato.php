<?php get_header(); ?>
<!-- container -->
<div class="container is-desktop">
	<!-- site-content -->
	<div class="site-content page">
    <div class="article-content">
      <div class="section-title">
        <h1>Conta com o Reconta</h1>
        <hr class="reconta-divider"/>
      </div>
      <?php the_content(); ?>
    </div>
  </div>
	<!-- /site-content -->
</div>
<!-- /container -->
<?php get_footer(); ?>