<?php get_header(); ?>
<!-- container -->
<div class="container is-desktop">
	<!-- site-content -->
	<div class="site-content page">
    <h1>Página de Contato</h1>
    <?php the_content(); ?>
	</div>
	<!-- /site-content -->
</div>
<!-- /container -->
<?php get_footer(); ?>